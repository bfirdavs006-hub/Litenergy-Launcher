# Light Energy Mobile — Launcher

## Структура файлов

```
app/
├── src/main/
│   ├── java/com/lightenergy/mobile/launcher/
│   │   └── LauncherActivity.kt          ← логика лаунчера
│   ├── res/
│   │   ├── layout/
│   │   │   └── activity_launcher.xml   ← разметка
│   │   ├── drawable/
│   │   │   ├── ic_flame_logo.xml       ← иконка огня (Vector Asset)
│   │   │   ├── bg_glow.xml             ← голубое свечение фона
│   │   │   └── bg_mobile_badge.xml     ← бейдж "MOBILE"
│   │   └── font/
│   │       ├── rajdhani_bold.ttf
│   │       └── rajdhani_semibold.ttf
│   └── AndroidManifest.xml
```

## build.gradle (app) — зависимости

```groovy
dependencies {
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
}
```

## AndroidManifest.xml — нужные разрешения

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
    android:maxSdkVersion="28" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />

<!-- Для Android 10+ кэш пиши во внутреннее хранилище: getExternalFilesDir() -->
```

## Что нужно поменять

| Место в коде | Что вставить |
|---|---|
| `SAMP_PACKAGE` | Package ID реального клиента SAMP Mobile |
| `SAMP_DEEP_LINK` | Deep-link схема клиента (если есть) |
| `CACHE_FILES` → `url` | Прямые ссылки на твои файлы кэша (CDN/GitHub Releases) |
| `ic_flame_logo` | Логотип из картинки (конвертируй JPG → Vector или WebP) |

## Drawable: bg_mobile_badge.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="#1A2A30"/>
    <corners android:radius="4dp"/>
</shape>
```

## Drawable: bg_glow.xml (радиальное свечение)

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="android/schemas.android.com/apk/res/android"
    android:shape="oval">
    <gradient
        android:type="radial"
        android:gradientRadius="400dp"
        android:startColor="#1A00E5FF"
        android:endColor="#000A0E12"
        android:centerX="0.5"
        android:centerY="0.4"/>
</shape>
```

## Шрифт Rajdhani

Скачай бесплатно: fonts.google.com/specimen/Rajdhani  
Положи .ttf в `res/font/`

## Как работает запуск игры

1. Нажимаешь **ИГРАТЬ** → вводишь ник
2. Лаунчер проверяет наличие кэш-файлов
3. Если нет → показывает прогресс-бар и качает
4. Когда всё готово → запускает игру через **Deep Link** или **Intent**
5. Ник передаётся через `putExtra("nickname", nick)`

## Для Android 13+ (READ_MEDIA_IMAGES)

Замени WRITE_EXTERNAL_STORAGE на:
```xml
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
```
И используй `getExternalFilesDir(null)` вместо `getExternalStorageDirectory()`
